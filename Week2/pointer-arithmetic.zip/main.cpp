// pointer arithmetic

#include <iostream>
using namespace std;

int main(){
    
    int arr[] = {1, 2, 3, 4, 5};
    int* ptr = arr; 
    
    cout << ptr << ' ' << *ptr << endl;
    ptr++; // Moves to the next element (2)
    cout << ptr << ' ' << *ptr << endl;
    ptr+=2; // increments the address by 2 * 4 bytes = 8
    cout << ptr << ' ' << *ptr << endl;
    
    
    // Array access using pointer arithmetic
    ptr = arr;    // assign ptr to beginning of array address
    for (int i = 0; i < 5; i++) {
        cout << *ptr << " ";
        ptr++;
    }
    


}
