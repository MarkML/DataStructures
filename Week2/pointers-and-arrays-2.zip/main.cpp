/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   int A[] = {2,4,5,8,1};
   cout << A << endl;
   cout << &A[0] << endl;
   cout << A[0] << endl;
   cout << *A << endl;
   
   // loop thru to print elements in the array
   for (int i = 0; i < 5; i++) {
       cout << A[i] << " ";
   }
   cout << endl;
   for (int i = 0; i < 5; ++i) {
       cout << *(A + i) << " ";
   }
}
