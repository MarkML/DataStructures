// late binding polymorphism

#include<iostream>
using namespace std;
//base class
class Animal {
  public:
    string name;
    Animal(string name) : name(name) {}
    virtual void makeSound() {
        cout << "make a sound" << endl;
    }
};

//derived class
class Mammal : public Animal {
  public:
    string hairColor;
    Mammal(string name, string color) : Animal(name), hairColor(color) {}
    void makeSound() {
        cout << "make roaring sounds" << endl;
    }
    
};

class Dog : public Mammal {
    public:
        string breed;
        Dog(string name, string color, string breed) :
            Mammal(name, color),
            breed(breed) {}
        void makeSound() {
            cout << "woof woof" << endl;
        }
};

int main() {
    Animal* animal;
    Dog peaches("Peaches", "brown", "terrier");
    animal = &peaches;
    animal->makeSound();
    peaches.makeSound();
    
    return 0;
}