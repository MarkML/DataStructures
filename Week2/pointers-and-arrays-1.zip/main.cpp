/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int arr[] = {1,2,3,4,5};
    
    int *ptr = arr;

    cout << arr << endl;
    cout << *arr << endl;    //arr is the address of the first element in the array which is index 0,
                             // dereferencing arr pointer gives us value at the address
    cout << arr[0] << endl;
    cout << arr + 1 << endl;
    cout << *(arr + 1);
    
    return 0;
}
