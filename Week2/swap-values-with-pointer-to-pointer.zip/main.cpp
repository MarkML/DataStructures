/******************************************************************************

function to swap two integers using pointer to pointers

*******************************************************************************/
#include <iostream>

using namespace std;

void swap(int** a, int** b ){
    int temp = **a;
    **a = **b;
    **b = temp;
}

int main()
{
    int num1 = 5;
    int num2 = 10;
    
    int* ptr1 = &num1;
    int* ptr2 = &num2;
    cout << "num1 = " << *ptr1 << endl;
    cout << "num2 = " << *ptr2 << endl;
    swap(&ptr1, &ptr2);
    // after swap 
    cout << "num1 = " << *ptr1 << endl;
    cout << "num2 = " << *ptr2 << endl;
    // num1 and num2 are swapped
    cout << "num1 is: " << num1 << endl;
    cout << "num2 is: " << num2 << endl;
    return 0;
}