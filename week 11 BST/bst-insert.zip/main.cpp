#include <iostream>

// Node definition for BST
class Node {
public:
    int key;
    Node *left;
    Node *right;

    Node(int value) : key(value), left(nullptr), right(nullptr) {}
};

// BST class definition
class BST {
private:
    Node *root;

public:
    BST() : root(nullptr) {}

    // Function to insert a new key into the BST
    void insert(int key) {
        // Create a new node
        Node *node = new Node(key);

        // If the BST is empty, set the new node as the root
        if (root == nullptr) {
            root = node;
            // No need to do anything else, so return from the function
            return;
        } else {
            // Otherwise, the BST is not empty. Start at the root to find the correct position for the new node
            Node *currentNode = root;
            // The loop will continue until we find the right spot to insert the new node
            while (true) {
                // If the new key is less than the current node's key, go left
                if (key < currentNode->key) {
                    // If there's no left child, the new node should be placed here
                    if (currentNode->left == nullptr) {
                        currentNode->left = node;
                        // Node has been inserted, end the loop
                        return;
                    } else {
                        // Otherwise, move to the left child and continue the process
                        currentNode = currentNode->left;
                    }
                } else {
                    // If the new key is greater than or equal to the current node's key, go right
                    if (currentNode->right == nullptr) {
                        currentNode->right = node;
                        // Node has been inserted, end the loop
                        return;
                    } else {
                        // Otherwise, move to the right child and continue the process
                        currentNode = currentNode->right;
                    }
                }
            }
        }
    }

    // Destructor to free memory
    ~BST() {
        destroyTree(root);
    }

private:
    // Helper function to delete all nodes of the BST
    void destroyTree(Node *node) {
        if (node) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }
};

int main() {
    BST tree;

    // Insert nodes into BST
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);
    tree.insert(17);

    // we would call display method here to show the tree,
    // we will now extend the class to include a traversal method and display method    


    return 0;
}
