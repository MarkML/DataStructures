#include <iostream>

// Node definition for BST
class Node {
public:
    int key;
    Node *left;
    Node *right;

    Node(int value) : key(value), left(nullptr), right(nullptr) {}
};

// BST class definition
class BST {
private:
    Node *root;

public:
    BST() : root(nullptr) {}

    // Function to insert a new key into the BST
    void insert(int key) {
        Node *node = new Node(key);

        if (root == nullptr) {
            root = node;
            return;
        } else {
            Node *currentNode = root;
            while (true) {
                if (key < currentNode->key) {
                    if (currentNode->left == nullptr) {
                        currentNode->left = node;
                        return;
                    }
                    currentNode = currentNode->left;
                } else {
                    if (currentNode->right == nullptr) {
                        currentNode->right = node;
                        return;
                    }
                    currentNode = currentNode->right;
                }
            }
        }
    }

    // Function to print the nodes of the BST in sorted order (inorder traversal)
    void BSTPrintInorder(Node *node) {
        if (node == nullptr) {
            return; // Base case: empty subtree
        }

        BSTPrintInorder(node->left);    // Recursively print the left subtree
        std::cout << node->key << " ";  // Print the current node's key
        BSTPrintInorder(node->right);   // Recursively print the right subtree
    }

    // Function to initiate the inorder traversal
    void printInorder() {
        BSTPrintInorder(root);
        std::cout << std::endl;
    }

    // Destructor to free memory
    ~BST() {
        destroyTree(root);
    }

private:
    // Helper function to delete all nodes of the BST
    void destroyTree(Node *node) {
        if (node) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }
};

int main() {
    BST tree;

    // Insert nodes into BST
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);
    tree.insert(17);

    // Print BST nodes in sorted order
    std::cout << "BST in sorted order: ";
    tree.printInorder();

    return 0;
}
