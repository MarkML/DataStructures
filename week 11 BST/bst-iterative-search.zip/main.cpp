#include <iostream>
using namespace std;

// Define the Node structure for BST
class Node {
public:
    int key;       // Value of the node
    Node* left;    // Pointer to the left child
    Node* right;   // Pointer to the right child

    // Constructor to create a new node
    Node(int item) : key(item), left(nullptr), right(nullptr) {}
};

// Define the BST class with the iterative search function
class BST {
private:
    Node* root; // Root of the BST

public:
    // Constructor initializes an empty BST
    BST() : root(nullptr) {}

    // Iterative search function for a key in the BST
    Node* search(int key) {
        Node* cur = root; // Start the search from the root
        
        // Continue searching until cur is NULL
        while (cur != nullptr) {
            if (key == cur->key) {
                // Key is found, return the current node
                return cur;
            } else if (key < cur->key) {
                // If key is less than cur's key, go left
                cur = cur->left;
            } else {
                // If key is greater than cur's key, go right
                cur = cur->right;
            }
        }
        
        // Key was not found in the tree
        return nullptr;
    }
};

int main() {
    // Manually create a BST for demonstration
    Node* root = new Node(8);
    root->left = new Node(3);
    root->right = new Node(10);
    root->left->left = new Node(1);
    root->left->right = new Node(6);
    root->right->right = new Node(14);
    root->left->right->left = new Node(4);
    root->left->right->right = new Node(7);
    root->right->right->left = new Node(13);

    // Instantiate BST and directly assign root for demonstration
    BST bst;
    *((Node**)&bst) = root; // Directly setting root for educational purposes

    // Search for a key
    int keyToSearch = 7;
    Node* result = bst.search(keyToSearch);

    if (result != nullptr) {
        cout << "Node with key " << keyToSearch << " found." << endl;
    } else {
        cout << "Node with key " << keyToSearch << " not found." << endl;
    }

    return 0;
}
