#include <iostream>

class Node {
public:
    int key;
    Node *left, *right;

    Node(int value) : key(value), left(nullptr), right(nullptr) {}
};

class BST {
private:
    Node *root;

    Node* removeRec(Node* node, int key) {
        if (node == nullptr) return nullptr; // Base case: Key not found

        // Recursive case: Traverse the tree
        if (key < node->key) {
            node->left = removeRec(node->left, key);
        } else if (key > node->key) {
            node->right = removeRec(node->right, key);
        } else {
            // Node with only one child or no child
            if (node->left == nullptr) {
                Node *temp = node->right;
                delete node;
                return temp;
            } else if (node->right == nullptr) {
                Node *temp = node->left;
                delete node;
                return temp;
            }

            // Node with two children: Get the inorder successor (smallest in the right subtree)
            Node *temp = minValueNode(node->right);

            // Copy the inorder successor's content to this node and delete the successor
            node->key = temp->key;
            node->right = removeRec(node->right, temp->key);
        }
        return node;
    }

    Node* minValueNode(Node* node) {
        Node* current = node;
        while (current && current->left != nullptr)
            current = current->left;
        return current;
    }

    void BSTPrintInorder(Node *node) {
        if (node == nullptr) return;

        BSTPrintInorder(node->left);
        std::cout << node->key << " ";
        BSTPrintInorder(node->right);
    }

    void destroyTree(Node *node) {
        if (node) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }

public:
    BST() : root(nullptr) {}

    void insert(int key) {
        root = insertRec(root, key);
    }

    Node* insertRec(Node* node, int key) {
        if (node == nullptr) {
            return new Node(key);
        }
        if (key < node->key) {
            node->left = insertRec(node->left, key);
        } else if (key > node->key) {
            node->right = insertRec(node->right, key);
        }
        return node;
    }

    void remove(int key) {
        root = removeRec(root, key);
    }

    void printInorder() {
        BSTPrintInorder(root);
        std::cout << std::endl;
    }

    ~BST() {
        destroyTree(root);
    }
};

int main() {
    BST tree;

    // Insert nodes into BST
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);
    tree.insert(17);

    std::cout << "BST in sorted order before removal: ";
    tree.printInorder();

    // Remove nodes from BST and print after each removal
    tree.remove(3); // Remove leaf
    std::cout << "BST after removing 3: ";
    tree.printInorder();

    tree.remove(15); // Remove node with one child
    std::cout << "BST after removing 15: ";
    tree.printInorder();

    tree.remove(5); // Remove node with two children
    std::cout << "BST after removing 5: ";
    tree.printInorder();

    return 0;
}
