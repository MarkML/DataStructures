/*
 * This file demonstrates the use of polymorphism in C++ through a simple social media application.
 * It defines a base class `Content` with a pure virtual function `display()`, and two derived classes `Post` and `Comment`.
 * Each derived class provides its own implementation of the `display()` method.
 * The `User` class represents a user in the application.
 * The `main()` function creates instances of `User`, `Post`, and `Comment`, and uses polymorphism to display content.
 */

#include <iostream>
#include <string>
#include <vector>

using namespace std;


// Base class Content
class Content {
public:
    // Pure virtual function to be overridden by derived classes
    virtual void display() const = 0;

    // Virtual destructor to ensure proper cleanup of derived class objects
    virtual ~Content() {}
};

// User class definition
class User {
public:
    string username;
    string email;
    string password;

    // Constructor
    User(const string& username, const string& email, const string& password)
        : username(username), email(email), password(password) {}

    // Method to get the username
    string getUsername() const {
        return username;
    }

    // Method to display user information
    void display() const {
        cout << "Username: " << username << ", Email: " << email << endl;
    }
};

// Post class definition inheriting from Content
class Post : public Content {
public:
    string title;
    string content;
    string author;
    string date;

    // Constructor
    Post(const string& title, const string& content, const string& author, const string& date)
        : title(title), content(content), author(author), date(date) {}

    // Method to like the post
    void likePost() {
        cout << "Post liked!" << endl;
    }

    // Overridden method to display post information
    void display() const override {
        cout << "Title: " << title << ", Content: " << content << ", Author: " << author << ", Date: " << date << endl;
    }
};

// Comment class definition inheriting from Content
class Comment : public Content {
public:
    string text;
    string author;
    string date;
    string postTitle;
    const Post& post;

    // Constructor
    Comment(const string& text, const string& author, const string& date, const string& postTitle, const Post& post)
        : text(text), author(author), date(date), postTitle(postTitle), post(post) {}

    // Overridden method to display comment information
    void display() const override {
        cout << "Text: " << text << ", Author: " << author << ", Date: " << date << ", Post Title: " << postTitle << endl;
    }
};

int main() {
    User user("_doe", "john@example.com", "password123");
    user.display();

    Post post("My Post", "This is the content of my first post.", user.getUsername(), "2023-10-01");
    post.display();
    post.likePost();

    Comment comment("Great post!", "jane_doe", "2023-10-02", "My First Post", post);
    comment.display();

    // Using polymorphism to handle different types of content
    vector<Content*> contents;
    contents.push_back(&post);
    contents.push_back(&comment);

    // Displaying all content using polymorphism
    cout << "\nDisplaying all content:\n";
    for (const auto& content : contents) {
        content->display(); // Polymorphic call: the correct display() method is called based on the actual object type (Post or Comment)
    }

    return 0;
}