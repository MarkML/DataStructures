#include "Comment.h"
#include <iostream>
using namespace std;

Comment::Comment(string uname, string uemail, strig upassword, string content, const Post& post)
       : User(uname, uemail, upassword), commentContent(content) {
           postDetails = "Post by " + post.getUsername() + ": " + content;
}
// overridden method to display the comment
void Comment::display() const {
    cout << "Comment by " << getUsername() << ": " << commentContent << endl;
    cout << "On: " << postDetails << endl;
}