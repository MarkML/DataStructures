#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
private:
    string username;
    string email;
    string password;
    
public:
    User(string uname, string uemail, string upassword);
    
    string getUsername() const;
    void setEmail(const string& newEmail);
    void updatePassword(const string& oldPassword, const string& newPassword);
    virtual void display() const;
    virtual ~User() {}
};

#endif