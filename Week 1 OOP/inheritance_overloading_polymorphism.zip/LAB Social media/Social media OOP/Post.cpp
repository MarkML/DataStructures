#include "Post.h"
#include <iostream>
#include <ctime>
using namespace std;

Post::Post(string uname, string uemail, string upassword, string postContent)
    : User(uname, uemail, upassword, content(postContent), likes(0) {
        timestamp = getCurrentTime();
}

string Post::getCurrentTime() {
    time_t now = time(0);
    return ctime(&now);
}

void Post::display() const {
    cout << "User: " << getUsername() << endl;
    cout << "Post: " << content << endl;
    cout << "Timestamp: " << timestamp << endl;
    cout << "Likes: " << likes << endl;
}

void Post::likePost() {
    likes++;
    cout << "Post liked! total likes: " << likes << endl;
}

    