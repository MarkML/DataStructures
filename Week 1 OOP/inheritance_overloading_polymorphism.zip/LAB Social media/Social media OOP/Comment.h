// Create Comment class with Polymorphism

#ifndef COMMENT_H
#define COMMENT_H
#include "User.h"
#include "Post.h"
#include <string>
using namespace std;

class Comment : public User {
private:
    string commentContent;
    string postDetails;

public:
    Comment(string uname, string uemail, string password, string content, const Post& post);

    void display() const override;
};

#endif