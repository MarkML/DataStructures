//Create Post Class with inheritance

#ifndef POST_H
#define POST_H

#include "User.h"
#include <string>
using namespace std;

class Post : public User {
private:
    string content;
    string timestamp;
    int likes;
    
    string getCurrentTime();

public:
    Post(string uname, string uemail, string upassword, string postContent);
    
    void display() const override;
    void editContent(const string& newContent);
    void likePost();
};

#endif