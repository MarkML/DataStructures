#include "User.h"
#include <iostream>
#include <regex>
using namespace std;

User::User(string uname, string uemail, string upassword) 
    : username(uname), email(uemail), password(upassword) {}
    
string User::getUsername() const {
    return username;
}

void User::setEmail(const string& newEmail) {
    regex emailPattern(R"((\w+)(\.\w+")*@(\w+)(\.\w+)+)");
    if (regex_match(newEmail, emailPattern)) {
        email = newEmail;
        cout << "Email updated successfully." << endl;
    } else {
        cout << "Invalid email format!" << endl;
    }
        
    
}

void User::updatePassword(const string& oldPassword, const string& newPassword) {
    if (oldPassword == password) {
        password = newPassword;
        cout << "Password updated successfully." << endl;
    } else {
        cout << "Incorrect old password." << endl;
    }
    
}

void User::display() const {
    cout << "Username: " << username << endl;
    cout << "Email: " << email << endl;
}

    