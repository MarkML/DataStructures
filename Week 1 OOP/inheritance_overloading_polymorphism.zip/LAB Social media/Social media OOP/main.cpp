#include "User.h"
#include "Post.h"
#include "Comment.h"
#include <iostream>
#include <vector>
using namespace std;

void displayItem(const User& item) {
    item.display();
}

int main() {
    Post post1("jane_doe", "jane@example.com", "mypassword", "This is my first post!");
    Comment comment1("john_doe", "john@example.com", "password123","Great post!", post1);
    post1.display();
    comment1.display();
    post1.likePost();
    //polymorphism demonstration
    vector<User*> items ={&post1, &comment1};
    for (const User* item : items) {
        item->display();
    }
}