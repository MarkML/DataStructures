/******************************************************************************

Polymorphism with virtual functions
code below works but its duplicative/inefficient
How do we improve its efficiency?  

*******************************************************************************/
#include <iostream>

using namespace std;

//base class
class Student {
    public:
        string name;
        Student(string name) : name(name) {}
        void print() {
            cout << name << endl;
        }
};

//Derived class from base class Student
class CoEStudent : public Student {
    public:
        string major;
        //When you create an object of a derived class, the constructor of the 
        //base class is always called first 
        //because a derived class object inherently contains the members of its base class.
        //Therefore, before the derived class can be fully initialized, the
        //base class portion of the object needs to be properly constructed. 
        CoEStudent(string name, string major) : Student(name), major(major) {}
        void print() {
            cout << name << ": " << major << endl;
        }
        
};
int main()
{
    Student bob("Bob");
    Student dave("Dave");
    Student jennifer("Jennifer");
    
    Student* students[] = { &bob, &dave, &jennifer};
    
    for (int i = 0; i < 3; i++) {
        students[i]->print();
    }
    
    CoEStudent john("John","computer science");
    CoEStudent frank("Frank","software engineering");
    CoEStudent mary("Mary", "ECE");
    
    CoEStudent* coeStudents[] = { &john, &frank, &mary };
    
    for (int i = 0; i < 3; i++) {
        coeStudents[i]->print();
    }

    return 0;
}
