#include <iostream>
#include <string>

using namespace std;

class Animal {
public:
    string name;
    int age;

    // Default constructor
    Animal() : name("Unknown"), age(0) {}

    // Constructor with name 
    Animal(string animalName) : name(animalName), age(0) {}

    // Constructor with name and age
    Animal(string animalName, int animalAge) : name(animalName), age(animalAge) {}

    void displayInfo() const {
        cout << "Animal Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

int main() {
    // Create Animal objects using different constructors
    Animal animal1; // Using default constructor
    Animal animal2("Lion"); // Using constructor with name
    Animal animal3("Elephant", 40); // Using constructor with name and age

    // Display information for each animal
    animal1.displayInfo(); 
    cout << endl;
    animal2.displayInfo(); 
    cout << endl;
    animal3.displayInfo(); 

    return 0;
}