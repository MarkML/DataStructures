/******************************************************************************

Operator Overloading

*******************************************************************************/
#include <iostream>

using namespace std;

class Vector {
public:
    int x, y;

    // Constructor to initialize x and y
    Vector(int x, int y) : x(x), y(y) {}

    // Overloaded '+' operator to add two Vector objects
    Vector operator+(const Vector& v) {
        return Vector(x + v.x, y + v.y);   // calls the Vector constructor to create a new Vector object
    }
};

int main() {
    // Creating two Vector objects
    Vector v1(10, 5);
    Vector v2(3, 4);

    // Using the overloaded '+' operator to add the two user-defined types
    Vector v3 = v1 + v2;

    // Displaying the result
    cout << "Resultant Vector: x = " << v3.x << ", y = " << v3.y << endl;

    return 0;
}

