#include "Student.h"

// Constructor definition
Student::Student(string n, double g) {
    name = n;
    gpa = g;
    cout << "Constructor called for student: " << name << endl;
}

// Destructor definition
Student::~Student() {
    cout << "Destructor called for student: " << name << endl;
}

// Set name
void Student::setName(string n) {
    name = n;
}

// Set GPA
void Student::setGPA(double g) {
    gpa = g;
}

// Get name
string Student::getName() {
    return name;
}

// Get GPA
double Student::getGPA() {
    return gpa;
}
