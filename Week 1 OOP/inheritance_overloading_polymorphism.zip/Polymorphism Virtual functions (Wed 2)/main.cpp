#include <iostream>
#include <vector>

using namespace std;

// Base class
class Shape {
public:
    virtual void draw() const { 
        // Virtual function allows derived classes to override this method
        cout << "Drawing a Shape" << endl; 
    } 
};

// Derived class 1
class Circle : public Shape {
public:
    void draw() const override { 
        // Override the base class's draw() method 
        cout << "Drawing a Circle" << endl; 
    }
};

// Derived class 2
class Square : public Shape {
public:
    void draw() const override { 
        // Override the base class's draw() method 
        cout << "Drawing a Square" << endl; 
    }
};

// Derived class 3 
class Triangle : public Shape {
public:
    void draw() const override { 
        // Override the base class's draw() method 
        cout << "Drawing a Triangle" << endl; 
    }
};

int main() {
    // Create objects of different shapes
    Circle circle;
    Square square;
    Triangle triangle;

    // Create a vector of Shape pointers
    vector<Shape*> shapes = {&circle, &square, &triangle};

    // Iterate through the vector and call draw() on each shape
    for (const auto& shape : shapes) {
        shape->draw(); 
    }

    return 0;
}