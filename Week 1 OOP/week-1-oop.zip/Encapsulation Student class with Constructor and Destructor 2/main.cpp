#include "Student.h"

int main() {
    // Create a Student object (constructor is called here)
    Student student1("Alice", 3.9);

    // Access and modify the student's details using public methods
    cout << "Student Name: " << student1.getName() << endl;
    cout << "Student GPA: " << student1.getGPA() << endl;

    // Change student's name and GPA
    student1.setName("Alice Smith");
    student1.setGPA(4.0);

    cout << "Updated Student Name: " << student1.getName() << endl;
    cout << "Updated Student GPA: " << student1.getGPA() << endl;

    // Destructor is automatically called when `student1` goes out of scope
    return 0;
}
