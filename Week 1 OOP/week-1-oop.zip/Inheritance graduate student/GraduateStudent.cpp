#include "GraduateStudent.h"

void GraduateStudent::setThesisTitle(string t) {
    thesisTitle = t;
}

string GraduateStudent::getThesisTitle() {
    return thesisTitle;
}
